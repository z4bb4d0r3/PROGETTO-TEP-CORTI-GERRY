
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

// Prodotto come ricevuto dal server
public class ProdottoBar
{
    public string Nome;
    public decimal Prezzo;
    public int Disponibili;
}

// Una riga del carrello (il carrello resta sul client fino alla conferma)
public class RigaCarrello
{
    public string Nome;
    public decimal Prezzo;
    public int Quantita;
}

public class SynchronousSocketClient
{
    static Socket sender;
    static byte[] bytes = new byte[1024];
    static string buffer = "";        // dati ricevuti non ancora elaborati

    // Coda delle risposte del server (riempita dal thread di ricezione)
    static BlockingCollection<string> risposte = new BlockingCollection<string>();

    static List<ProdottoBar> prodotti = new List<ProdottoBar>();   // ultima lista ricevuta
    static List<RigaCarrello> carrello = new List<RigaCarrello>();
    static bool inUscita = false;

    public static int Main(String[] args)
    {
        string ip = args.Length > 0 ? args[0] : "127.0.0.1";
        int porta = 5000;
        if (args.Length > 1) int.TryParse(args[1], out porta);

        Console.WriteLine("=== TCPanino - Ordina al bar della scuola ===");
        Console.Write("Come ti chiami? ");
        string nome = Console.ReadLine();
        if (nome == null) return 0;
        nome = nome.Replace("$", "").Replace("|", "").Replace(";", "").Trim();
        if (nome == "") nome = "Studente";

        try
        {
            IPAddress ipAddress = IPAddress.Parse(ip);
            IPEndPoint remoteEP = new IPEndPoint(ipAddress, porta);
            sender = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            sender.Connect(remoteEP);
            Console.WriteLine("Connesso al server {0}", sender.RemoteEndPoint.ToString());
        }
        catch (Exception e)
        {
            Console.WriteLine("Impossibile collegarsi al server: " + e.Message);
            return 1;
        }

        // Avvio il thread che riceve risposte e notifiche
        Thread tRicezione = new Thread(new ThreadStart(Ricezione));
        tRicezione.IsBackground = true;
        tRicezione.Start();

        // Mi presento al server.
        // Se entro 5 secondi non arriva il benvenuto di TCPanino, sulla porta
        // risponde un altro programma (oppure il server non e' quello giusto).
        Invia("NOME|" + nome);
        string benvenuto;
        if (!risposte.TryTake(out benvenuto, 5000) || !benvenuto.StartsWith("OK|"))
        {
            inUscita = true;
            Console.WriteLine("Sulla porta {0} ha risposto un programma che NON e' il server TCPanino.", porta);
            Console.WriteLine("Controlla che il server sia avviato oppure usa un'altra porta, sia nel server che nel client.");
            Console.WriteLine("Per vedere chi usa la porta:  netstat -ano | findstr :{0}", porta);
            Console.WriteLine("Premi INVIO per uscire.");
            Console.ReadLine();
            return 1;
        }
        Console.WriteLine(Testo(benvenuto));

        Menu();

        // Uscita
        inUscita = true;
        try
        {
            Invia("QUIT");
            sender.Shutdown(SocketShutdown.Both);
            sender.Close();
        }
        catch (Exception) { }
        Console.WriteLine("Arrivederci!");
        return 0;
    }

    // =================================================================
    //  COMUNICAZIONE
    // =================================================================

    // Invia un messaggio aggiungendo il terminatore '$'
    static void Invia(string messaggio)
    {
        byte[] msg = Encoding.ASCII.GetBytes(messaggio + "$");
        sender.Send(msg);
    }

    // Invia una richiesta e aspetta la risposta del server
    static string Richiesta(string messaggio)
    {
        Invia(messaggio);
        return risposte.Take();
    }

    // Legge un messaggio completo fino al '$' (null = connessione chiusa).
    // Un messaggio puo' arrivare a pezzi o insieme ad altri: il resto
    // dopo il '$' rimane nel buffer per la lettura successiva.
    static string RiceviMessaggio()
    {
        while (buffer.IndexOf("$") == -1)
        {
            int bytesRec = sender.Receive(bytes);
            if (bytesRec == 0) return null;
            buffer += Encoding.ASCII.GetString(bytes, 0, bytesRec);
        }
        int pos = buffer.IndexOf("$");
        string messaggio = buffer.Substring(0, pos);
        buffer = buffer.Substring(pos + 1);
        return messaggio;
    }

    // Thread di ricezione: separa notifiche asincrone e risposte
    static void Ricezione()
    {
        try
        {
            string data;
            while ((data = RiceviMessaggio()) != null)
            {
                if (data.StartsWith("NOTIFICA|"))
                {
                    Console.WriteLine();
                    Console.WriteLine("  *** NOTIFICA: {0} ***", Testo(data));
                }
                else
                {
                    risposte.Add(data);
                }
            }
        }
        catch (Exception) { }

        if (!inUscita)
        {
            Console.WriteLine();
            Console.WriteLine("Connessione con il server persa.");
            Environment.Exit(1);
        }
    }

    // Da "TIPO|testo" restituisce "testo"
    static string Testo(string messaggio)
    {
        int pos = messaggio.IndexOf('|');
        return pos >= 0 ? messaggio.Substring(pos + 1) : messaggio;
    }

    static string Euro(decimal valore)
    {
        return valore.ToString("0.00") + " EUR";
    }

    // =================================================================
    //  MENU
    // =================================================================
    static void Menu()
    {
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("------ MENU ------");
            Console.WriteLine("1. Visualizza prodotti");
            Console.WriteLine("2. Aggiungi prodotto al carrello");
            Console.WriteLine("3. Modifica quantita' nel carrello");
            Console.WriteLine("4. Rimuovi prodotto dal carrello");
            Console.WriteLine("5. Riepilogo carrello");
            Console.WriteLine("6. Conferma ordine");
            Console.WriteLine("7. I miei ordini");
            Console.WriteLine("8. Annulla un ordine confermato");
            Console.WriteLine("0. Esci");
            Console.Write("Scelta: ");

            string scelta = Console.ReadLine();
            if (scelta == null) return;   // input chiuso
            switch (scelta.Trim())
            {
                case "1": MostraProdotti(); break;
                case "2": AggiungiAlCarrello(); break;
                case "3": ModificaCarrello(); break;
                case "4": RimuoviDalCarrello(); break;
                case "5": MostraCarrello(); break;
                case "6": ConfermaOrdine(); break;
                case "7": MostraMieiOrdini(); break;
                case "8": AnnullaOrdine(); break;
                case "0": return;
                default: Console.WriteLine("Scelta non valida."); break;
            }
        }
    }

    // Legge un numero intero da tastiera (-1 se non valido)
    static int LeggiNumero(string domanda)
    {
        Console.Write(domanda);
        int n;
        if (int.TryParse(Console.ReadLine(), out n)) return n;
        return -1;
    }

    // Chiede la lista al server e la stampa numerata
    static void MostraProdotti()
    {
        string risposta = Richiesta("LISTA");
        // PRODOTTI|Panino;3.00;10|Toast;2.50;8|...
        prodotti.Clear();
        string[] campi = risposta.Split('|');
        for (int i = 1; i < campi.Length; i++)
        {
            string[] p = campi[i].Split(';');
            ProdottoBar prodotto = new ProdottoBar();
            prodotto.Nome = p[0];
            prodotto.Prezzo = decimal.Parse(p[1], CultureInfo.InvariantCulture);
            prodotto.Disponibili = int.Parse(p[2]);
            prodotti.Add(prodotto);
        }

        Console.WriteLine("   {0,-12} {1,10} {2,12}", "PRODOTTO", "PREZZO", "DISPONIBILI");
        for (int i = 0; i < prodotti.Count; i++)
        {
            ProdottoBar p = prodotti[i];
            string disp = p.Disponibili > 0 ? p.Disponibili.ToString() : "ESAURITO";
            Console.WriteLine("{0}. {1,-12} {2,10} {3,12}", i + 1, p.Nome, Euro(p.Prezzo), disp);
        }
    }

    static RigaCarrello CercaNelCarrello(string nome)
    {
        foreach (RigaCarrello r in carrello)
            if (r.Nome == nome) return r;
        return null;
    }

    static void AggiungiAlCarrello()
    {
        MostraProdotti();   // lista aggiornata
        int n = LeggiNumero("Numero del prodotto: ");
        if (n < 1 || n > prodotti.Count) { Console.WriteLine("Prodotto non valido."); return; }
        ProdottoBar p = prodotti[n - 1];

        int quantita = LeggiNumero("Quantita': ");
        if (quantita <= 0) { Console.WriteLine("Quantita' non valida."); return; }

        // Controllo indicativo: quello definitivo lo fa il server alla conferma
        RigaCarrello riga = CercaNelCarrello(p.Nome);
        int giaNelCarrello = riga != null ? riga.Quantita : 0;
        if (giaNelCarrello + quantita > p.Disponibili)
        {
            Console.WriteLine("Disponibili solo {0} {1}.", p.Disponibili, p.Nome);
            return;
        }

        if (riga == null)
        {
            riga = new RigaCarrello();
            riga.Nome = p.Nome;
            riga.Prezzo = p.Prezzo;
            carrello.Add(riga);
        }
        riga.Quantita += quantita;
        Console.WriteLine("Aggiunto: {0} x{1}", p.Nome, quantita);
    }

    // Stampa il carrello numerato; restituisce false se e' vuoto
    static bool MostraCarrello()
    {
        if (carrello.Count == 0) { Console.WriteLine("Il carrello e' vuoto."); return false; }
        decimal totale = 0;
        Console.WriteLine("--- Carrello ---");
        for (int i = 0; i < carrello.Count; i++)
        {
            RigaCarrello r = carrello[i];
            decimal subtotale = r.Prezzo * r.Quantita;
            totale += subtotale;
            Console.WriteLine("{0}. {1,-12} x{2,-3} {3,10}", i + 1, r.Nome, r.Quantita, Euro(subtotale));
        }
        Console.WriteLine("TOTALE: {0}", Euro(totale));
        return true;
    }

    static void ModificaCarrello()
    {
        if (!MostraCarrello()) return;
        int n = LeggiNumero("Riga da modificare: ");
        if (n < 1 || n > carrello.Count) { Console.WriteLine("Riga non valida."); return; }
        int quantita = LeggiNumero("Nuova quantita' (0 = rimuovi): ");
        if (quantita < 0) { Console.WriteLine("Quantita' non valida."); return; }
        if (quantita == 0)
            carrello.RemoveAt(n - 1);
        else
            carrello[n - 1].Quantita = quantita;
        Console.WriteLine("Carrello aggiornato.");
    }

    static void RimuoviDalCarrello()
    {
        if (!MostraCarrello()) return;
        int n = LeggiNumero("Riga da rimuovere: ");
        if (n < 1 || n > carrello.Count) { Console.WriteLine("Riga non valida."); return; }
        Console.WriteLine("Rimosso: {0}", carrello[n - 1].Nome);
        carrello.RemoveAt(n - 1);
    }

    static void ConfermaOrdine()
    {
        if (!MostraCarrello()) return;
        Console.Write("Confermi l'ordine? (s/n): ");
        string r = Console.ReadLine();
        if (r == null || r.Trim().ToLower() != "s") { Console.WriteLine("Ordine non inviato."); return; }

        // ORDINA|Panino;2|Acqua;1
        string messaggio = "ORDINA";
        foreach (RigaCarrello riga in carrello)
            messaggio += "|" + riga.Nome + ";" + riga.Quantita;

        string risposta = Richiesta(messaggio);
        string[] campi = risposta.Split('|');
        if (campi[0] == "ORDINE_OK")
        {
            decimal totale = decimal.Parse(campi[2], CultureInfo.InvariantCulture);
            Console.WriteLine("Ordine confermato! Il tuo numero d'ordine e' #{0} - Totale {1}", campi[1], Euro(totale));
            carrello.Clear();
        }
        else
        {
            Console.WriteLine("Ordine NON confermato: " + Testo(risposta));
        }
    }

    // Stampa gli ordini dello studente; restituisce false se non ce ne sono
    static bool MostraMieiOrdini()
    {
        string risposta = Richiesta("MIEI");
        // ORDINI|5;CONFERMATO;6.50;Panino x2, Acqua x1|...
        string[] campi = risposta.Split('|');
        if (campi.Length <= 1) { Console.WriteLine("Non hai ancora ordini."); return false; }
        for (int i = 1; i < campi.Length; i++)
        {
            string[] o = campi[i].Split(';');
            decimal totale = decimal.Parse(o[2], CultureInfo.InvariantCulture);
            Console.WriteLine("#{0,-3} {1,-11} {2,10}  {3}", o[0], o[1], Euro(totale), o[3]);
        }
        return true;
    }

    static void AnnullaOrdine()
    {
        if (!MostraMieiOrdini()) return;
        int n = LeggiNumero("Numero dell'ordine da annullare: ");
        if (n < 1) { Console.WriteLine("Numero non valido."); return; }
        string risposta = Richiesta("ANNULLA|" + n);
        Console.WriteLine(Testo(risposta));
    }
}
