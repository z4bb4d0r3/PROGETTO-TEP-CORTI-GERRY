
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

// Un prodotto del magazzino del bar
public class Prodotto
{
    public string Nome;
    public decimal Prezzo;
    public int Quantita;

    public Prodotto(string nome, decimal prezzo, int quantita)
    {
        Nome = nome;
        Prezzo = prezzo;
        Quantita = quantita;
    }
}

// Un ordine confermato da uno studente
public class Ordine
{
    public int Numero;
    public ClientManager Proprietario;              // client che ha fatto l'ordine
    public string NomeStudente;
    public Dictionary<string, int> Prodotti = new Dictionary<string, int>();  // nome prodotto -> quantita
    public decimal Totale;
    public string Stato;                            // CONFERMATO, PRONTO, RITIRATO, ANNULLATO

    // Es. "Panino x2, Acqua x1"
    public string DescrizioneProdotti()
    {
        List<string> parti = new List<string>();
        foreach (KeyValuePair<string, int> p in Prodotti)
            parti.Add(p.Key + " x" + p.Value);
        return string.Join(", ", parti);
    }
}

public class SynchronousSocketListener
{
    // ----------------- CONFIGURAZIONE (modificabile) -----------------
    public static int PORTA = 5000;

    // Orario di inizio dell'intervallo (ore, minuti, secondi)
    public static TimeSpan ORA_INIZIO_INTERVALLO = new TimeSpan(10, 50, 0);
    public static int DURATA_INTERVALLO_MINUTI = 10;

    // Modalita' test: un "minuto" dura pochi secondi e l'intervallo
    // inizia poco dopo l'avvio del server.
    public static bool MODALITA_TEST = false;
    public static int TEST_SECONDI_PER_MINUTO = 10;  // in test 1 minuto = 10 secondi
    public static int TEST_MINUTI_PRIMA_INIZIO = 6;  // in test l'intervallo inizia dopo 6 "minuti" (60 s)

    // ----------------- DATI CONDIVISI TRA I THREAD -----------------
    // Magazzino iniziale (valori modificabili)
    public static List<Prodotto> magazzino = new List<Prodotto>()
    {
        new Prodotto("Panino",    3.00m, 10),
        new Prodotto("Toast",     2.50m, 8),
        new Prodotto("Acqua",     1.00m, 15),
        new Prodotto("Coca-Cola", 1.50m, 10),
        new Prodotto("Patatine",  1.50m, 8),
    };

    public static List<Ordine> ordini = new List<Ordine>();
    public static int prossimoNumeroOrdine = 1;
    public static bool ordiniAperti = true;          // false quando inizia l'intervallo
    public static string statoIntervallo = "NON INIZIATO";

    // Lock unico per magazzino, ordini e stato: un solo thread alla volta
    // puo' modificarli (evita che due client comprino l'ultimo panino).
    public static object lockDati = new object();

    // Lista dei client connessi (con il suo lock)
    public static List<ClientManager> clientConnessi = new List<ClientManager>();
    public static object lockClient = new object();

    // =================================================================
    //  AVVIO DEL SERVER
    // =================================================================
    public static int Main(String[] args)
    {
        // Argomenti opzionali: porta e "test"
        foreach (string a in args)
        {
            int p;
            if (a.ToLower() == "test") MODALITA_TEST = true;
            else if (int.TryParse(a, out p)) PORTA = p;
        }

        Console.WriteLine("=== TCPanino - Server del bar ===");
        Console.WriteLine("Porta: {0}   Modalita' test: {1}", PORTA, MODALITA_TEST ? "SI" : "NO");

        // Thread che accetta le connessioni (come nell'esempio del professore)
        Thread tAscolto = new Thread(new ThreadStart(StartListening));
        tAscolto.IsBackground = true;
        tAscolto.Start();

        // Thread che gestisce i tempi dell'intervallo
        Thread tTimer = new Thread(new ThreadStart(GestioneIntervallo));
        tTimer.IsBackground = true;
        tTimer.Start();

        // Il thread principale gestisce il menu del personale del bar
        MenuPersonale();
        return 0;
    }

    // Accetta le connessioni e avvia un thread per ogni client
    public static void StartListening()
    {
        IPAddress ipAddress = IPAddress.Any;
        IPEndPoint localEndPoint = new IPEndPoint(ipAddress, PORTA);

        Socket listener = new Socket(ipAddress.AddressFamily,
            SocketType.Stream, ProtocolType.Tcp);

        try
        {
            listener.Bind(localEndPoint);
            listener.Listen(10);
            Console.WriteLine("In attesa di connessioni sulla porta {0}...", PORTA);

            while (true)
            {
                // Il thread resta fermo qui finche' non arriva un client
                Socket handler = listener.Accept();

                ClientManager clientThread = new ClientManager(handler);
                lock (lockClient)
                {
                    clientConnessi.Add(clientThread);
                }
                Thread t = new Thread(new ThreadStart(clientThread.doClient));
                t.IsBackground = true;
                t.Start();
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Errore del server: " + e.Message);
            Environment.Exit(1);
        }
    }

    // =================================================================
    //  NOTIFICHE
    // =================================================================

    // Invia un messaggio a tutti i client connessi
    public static void Broadcast(string testo)
    {
        List<ClientManager> copia;
        lock (lockClient)
        {
            copia = new List<ClientManager>(clientConnessi);
        }
        foreach (ClientManager c in copia)
            c.Invia("NOTIFICA|" + testo);
        Console.WriteLine("[BROADCAST] " + testo);
    }

    // =================================================================
    //  GESTIONE DELL'INTERVALLO (thread dedicato)
    // =================================================================

    // Durata di un "minuto": 60 secondi, oppure pochi secondi in modalita' test
    static TimeSpan Minuti(int n)
    {
        int secondiPerMinuto = MODALITA_TEST ? TEST_SECONDI_PER_MINUTO : 60;
        return TimeSpan.FromSeconds(n * secondiPerMinuto);
    }

    // Sospende il thread fino all'istante indicato (nessun polling continuo)
    static void AttendiFino(DateTime istante)
    {
        TimeSpan attesa = istante - DateTime.Now;
        if (attesa > TimeSpan.Zero)
            Thread.Sleep(attesa);
    }

    public static DateTime inizioIntervallo;
    public static DateTime fineIntervallo;

    public static void GestioneIntervallo()
    {
        if (MODALITA_TEST)
            inizioIntervallo = DateTime.Now + Minuti(TEST_MINUTI_PRIMA_INIZIO);
        else
            inizioIntervallo = DateTime.Today + ORA_INIZIO_INTERVALLO;
        fineIntervallo = inizioIntervallo + Minuti(DURATA_INTERVALLO_MINUTI);

        Console.WriteLine("Intervallo: dalle {0:HH:mm:ss} alle {1:HH:mm:ss}", inizioIntervallo, fineIntervallo);

        // Avviso: mancano 3 minuti
        DateTime avviso3 = inizioIntervallo - Minuti(3);
        if (DateTime.Now < avviso3)
        {
            AttendiFino(avviso3);
            Broadcast("Mancano 3 minuti all'intervallo: affrettati a ordinare!");
        }

        // Avviso: manca 1 minuto
        DateTime avviso1 = inizioIntervallo - Minuti(1);
        if (DateTime.Now < avviso1)
        {
            AttendiFino(avviso1);
            Broadcast("Manca 1 minuto all'intervallo: ultimi ordini!");
        }

        // Inizio intervallo: stop ai nuovi ordini (deciso dal server, non dai client)
        AttendiFino(inizioIntervallo);
        if (DateTime.Now < fineIntervallo)
        {
            lock (lockDati)
            {
                ordiniAperti = false;
                statoIntervallo = "IN CORSO";
            }
            Broadcast("E' iniziato l'intervallo! Ordini CHIUSI. Puoi ritirare il tuo ordine al bar fino alle "
                + fineIntervallo.ToString("HH:mm:ss") + ".");

            // Timer di 10 minuti: durante questo tempo si ritirano gli ordini
            AttendiFino(fineIntervallo);
        }

        lock (lockDati)
        {
            ordiniAperti = false;
            statoIntervallo = "TERMINATO";
        }
        Broadcast("L'intervallo e' terminato. Il bar e' chiuso.");
    }

    // Testo inviato a un nuovo client per informarlo sui tempi
    public static string InfoOrari()
    {
        lock (lockDati)
        {
            if (statoIntervallo == "NON INIZIATO")
                return "Ordini aperti fino all'inizio dell'intervallo, alle " + inizioIntervallo.ToString("HH:mm:ss") + ".";
            if (statoIntervallo == "IN CORSO")
                return "Intervallo in corso: ordini chiusi, ritiro fino alle " + fineIntervallo.ToString("HH:mm:ss") + ".";
            return "L'intervallo e' terminato: ordini chiusi.";
        }
    }

    // =================================================================
    //  LOGICA DEGLI ORDINI (chiamata dai thread dei client)
    // =================================================================

    static Prodotto CercaProdotto(string nome)
    {
        foreach (Prodotto p in magazzino)
            if (p.Nome.ToLower() == nome.ToLower())
                return p;
        return null;
    }

    static Ordine CercaOrdine(int numero)
    {
        foreach (Ordine o in ordini)
            if (o.Numero == numero)
                return o;
        return null;
    }

    // Messaggio con la lista prodotti: PRODOTTI|Panino;3.00;10|Toast;2.50;8...
    public static string ListaProdotti()
    {
        lock (lockDati)
        {
            string msg = "PRODOTTI";
            foreach (Prodotto p in magazzino)
                msg += "|" + p.Nome + ";" + p.Prezzo.ToString("0.00", CultureInfo.InvariantCulture) + ";" + p.Quantita;
            return msg;
        }
    }

    // Conferma un ordine. "righe" sono stringhe "Panino;2".
    // Restituisce il messaggio di errore, oppure null se l'ordine e' riuscito
    // (la conferma viene inviata qui dentro). Le notifiche di
    // prodotto esaurito vengono inviate a tutti DOPO la risposta.
    public static string ConfermaOrdine(ClientManager client, string[] righe)
    {
        List<string> esauriti = new List<string>();
        string risposta;
        Ordine ordine = new Ordine();

        // Il controllo della disponibilita' e l'aggiornamento del magazzino
        // avvengono dentro lo stesso lock: e' un'operazione "atomica".
        lock (lockDati)
        {
            if (!ordiniAperti)
                return "ERRORE|Le ordinazioni sono chiuse.";

            // 1) Lettura e verifica di tutte le righe
            foreach (string riga in righe)
            {
                string[] campi = riga.Split(';');
                int quantita;
                if (campi.Length != 2 || !int.TryParse(campi[1], out quantita) || quantita <= 0)
                    return "ERRORE|Formato ordine non valido.";
                Prodotto p = CercaProdotto(campi[0]);
                if (p == null)
                    return "ERRORE|Prodotto inesistente: " + campi[0];

                int giaRichiesti = ordine.Prodotti.ContainsKey(p.Nome) ? ordine.Prodotti[p.Nome] : 0;
                ordine.Prodotti[p.Nome] = giaRichiesti + quantita;
            }
            if (ordine.Prodotti.Count == 0)
                return "ERRORE|Il carrello e' vuoto.";

            foreach (KeyValuePair<string, int> r in ordine.Prodotti)
            {
                Prodotto p = CercaProdotto(r.Key);
                if (p.Quantita < r.Value)
                    return "ERRORE|Disponibilita' insufficiente per " + p.Nome + " (disponibili: " + p.Quantita + ").";
            }

            // 2) Tutto disponibile: scalo le quantita' e calcolo il totale
            foreach (KeyValuePair<string, int> r in ordine.Prodotti)
            {
                Prodotto p = CercaProdotto(r.Key);
                p.Quantita -= r.Value;
                ordine.Totale += p.Prezzo * r.Value;
                if (p.Quantita == 0)
                    esauriti.Add(p.Nome);
            }

            // 3) Registro l'ordine con un numero progressivo univoco
            ordine.Numero = prossimoNumeroOrdine;
            prossimoNumeroOrdine++;
            ordine.Proprietario = client;
            ordine.NomeStudente = client.Nome;
            ordine.Stato = "CONFERMATO";
            ordini.Add(ordine);

            risposta = "ORDINE_OK|" + ordine.Numero + "|" + ordine.Totale.ToString("0.00", CultureInfo.InvariantCulture);
        }

        Console.WriteLine("\n>>> NUOVO ORDINE #{0} da {1}: {2} - Totale {3:0.00} EUR",
            ordine.Numero, ordine.NomeStudente, ordine.DescrizioneProdotti(), ordine.Totale);

        // Prima rispondo al client, poi (fuori dal lock) avviso tutti
        client.Invia(risposta);
        foreach (string nome in esauriti)
            Broadcast("Il prodotto " + nome + " e' ESAURITO.");

        return null;    // risposta gia' inviata
    }

    // Annulla un ordine: solo il proprietario, solo se CONFERMATO e ordini aperti.
    // Come ConfermaOrdine: restituisce l'errore, oppure null se ha gia' risposto.
    public static string AnnullaOrdine(ClientManager client, int numero)
    {
        List<string> tornatiDisponibili = new List<string>();

        lock (lockDati)
        {
            Ordine o = CercaOrdine(numero);
            if (o == null || o.Proprietario != client)
                return "ERRORE|Non hai nessun ordine con numero " + numero + ".";
            if (o.Stato != "CONFERMATO")
                return "ERRORE|L'ordine #" + numero + " e' " + o.Stato + " e non puo' piu' essere annullato.";
            if (!ordiniAperti)
                return "ERRORE|Le ordinazioni sono chiuse: non e' piu' possibile annullare.";

            // Ripristino le quantita' in magazzino
            foreach (KeyValuePair<string, int> r in o.Prodotti)
            {
                Prodotto p = CercaProdotto(r.Key);
                if (p.Quantita == 0)
                    tornatiDisponibili.Add(p.Nome);
                p.Quantita += r.Value;
            }
            o.Stato = "ANNULLATO";
        }

        Console.WriteLine("\n>>> ORDINE #{0} ANNULLATO da {1}", numero, client.Nome);
        client.Invia("OK|Ordine #" + numero + " annullato.");
        foreach (string nome in tornatiDisponibili)
            Broadcast("Il prodotto " + nome + " e' di nuovo DISPONIBILE.");

        return null;    // risposta gia' inviata
    }

    // Ordini di un client: ORDINI|5;CONFERMATO;6.50;Panino x2, Acqua x1|...
    public static string OrdiniDelClient(ClientManager client)
    {
        lock (lockDati)
        {
            string msg = "ORDINI";
            foreach (Ordine o in ordini)
                if (o.Proprietario == client)
                    msg += "|" + o.Numero + ";" + o.Stato + ";"
                        + o.Totale.ToString("0.00", CultureInfo.InvariantCulture) + ";" + o.DescrizioneProdotti();
            return msg;
        }
    }

    // =================================================================
    //  MENU DEL PERSONALE DEL BAR (thread principale)
    // =================================================================
    public static void MenuPersonale()
    {
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("------ MENU BAR ------");
            Console.WriteLine("1. Visualizza magazzino");
            Console.WriteLine("2. Visualizza tutti gli ordini");
            Console.WriteLine("3. Segna un ordine come PRONTO");
            Console.WriteLine("4. Segna un ordine come RITIRATO");
            Console.WriteLine("5. Statistiche");
            Console.WriteLine("6. Client connessi");
            Console.WriteLine("7. Invia un messaggio a tutti");
            Console.WriteLine("0. Spegni il server");
            Console.Write("Scelta: ");

            string scelta = Console.ReadLine();
            if (scelta == null) { Thread.Sleep(Timeout.Infinite); return; }  // input chiuso: resta attivo solo il server
            switch (scelta.Trim())
            {
                case "1": MostraMagazzino(); break;
                case "2": MostraOrdini(); break;
                case "3": CambiaStatoOrdine("CONFERMATO", "PRONTO"); break;
                case "4": CambiaStatoOrdine("PRONTO", "RITIRATO"); break;
                case "5": MostraStatistiche(); break;
                case "6": MostraClient(); break;
                case "7":
                    Console.Write("Messaggio: ");
                    string testo = Pulisci(Console.ReadLine());
                    if (testo != "") Broadcast("Messaggio dal bar: " + testo);
                    break;
                case "0":
                    Broadcast("Il server del bar si sta spegnendo.");
                    Environment.Exit(0);
                    break;
                default: Console.WriteLine("Scelta non valida."); break;
            }
        }
    }

    static void MostraMagazzino()
    {
        lock (lockDati)
        {
            Console.WriteLine("{0,-12} {1,8} {2,12}", "PRODOTTO", "PREZZO", "DISPONIBILI");
            foreach (Prodotto p in magazzino)
                Console.WriteLine("{0,-12} {1,8:0.00} {2,12}", p.Nome, p.Prezzo, p.Quantita);
            Console.WriteLine("Ordini: {0} - Intervallo: {1}", ordiniAperti ? "APERTI" : "CHIUSI", statoIntervallo);
        }
    }

    static void MostraOrdini()
    {
        lock (lockDati)
        {
            if (ordini.Count == 0) { Console.WriteLine("Nessun ordine."); return; }
            foreach (Ordine o in ordini)
                Console.WriteLine("#{0,-3} {1,-12} {2,-11} {3,6:0.00} EUR  {4}",
                    o.Numero, o.NomeStudente, o.Stato, o.Totale, o.DescrizioneProdotti());
        }
    }

    // Cambia lo stato di un ordine (CONFERMATO->PRONTO oppure PRONTO->RITIRATO)
    static void CambiaStatoOrdine(string statoRichiesto, string nuovoStato)
    {
        Console.Write("Numero dell'ordine: ");
        int numero;
        if (!int.TryParse(Console.ReadLine(), out numero)) { Console.WriteLine("Numero non valido."); return; }

        ClientManager proprietario;
        lock (lockDati)
        {
            Ordine o = CercaOrdine(numero);
            if (o == null) { Console.WriteLine("Ordine inesistente."); return; }
            if (o.Stato != statoRichiesto)
            {
                Console.WriteLine("L'ordine e' {0}: deve essere {1}.", o.Stato, statoRichiesto);
                return;
            }
            o.Stato = nuovoStato;
            proprietario = o.Proprietario;
        }
        Console.WriteLine("Ordine #{0} ora e' {1}.", numero, nuovoStato);

        // La notifica di ordine pronto va SOLO al client proprietario
        if (nuovoStato == "PRONTO")
        {
            if (proprietario.Connesso)
                proprietario.Invia("NOTIFICA|Il tuo ordine #" + numero + " e' PRONTO! Passa a ritirarlo al bar.");
            else
                Console.WriteLine("(lo studente non e' piu' connesso, notifica non inviata)");
        }
    }

    static void MostraStatistiche()
    {
        int ricevuti, completati = 0, annullati = 0, inCorso = 0;
        lock (lockDati)
        {
            ricevuti = ordini.Count;
            foreach (Ordine o in ordini)
            {
                if (o.Stato == "RITIRATO") completati++;
                else if (o.Stato == "ANNULLATO") annullati++;
                else inCorso++;
            }
        }
        Console.WriteLine("Ordini ricevuti:   {0}", ricevuti);
        Console.WriteLine("Ordini completati: {0}", completati);
        Console.WriteLine("Ordini annullati:  {0}", annullati);
        Console.WriteLine("Ordini da ritirare (confermati o pronti): {0}", inCorso);
    }

    static void MostraClient()
    {
        lock (lockClient)
        {
            Console.WriteLine("Client connessi: {0}", clientConnessi.Count);
            foreach (ClientManager c in clientConnessi)
                Console.WriteLine(" - {0} ({1})", c.Nome, c.Indirizzo);
        }
    }

    // Toglie i caratteri riservati del protocollo dai testi
    public static string Pulisci(string testo)
    {
        if (testo == null) return "";
        return testo.Replace("$", "").Replace("|", "").Replace(";", "").Trim();
    }
}

// =====================================================================
//  GESTIONE DI UN SINGOLO CLIENT (un thread per ogni studente)
// =====================================================================
public class ClientManager
{
    Socket clientSocket;
    byte[] bytes = new Byte[1024];
    String buffer = "";                 // dati ricevuti ma non ancora elaborati
    object lockInvio = new object();    // piu' thread possono inviare allo stesso client

    public string Nome = "Sconosciuto";
    public string Indirizzo;
    public bool Connesso = true;

    public ClientManager(Socket clientSocket)
    {
        this.clientSocket = clientSocket;
        Indirizzo = clientSocket.RemoteEndPoint.ToString();
    }

    // Legge UN messaggio completo (fino al '$').
    // TCP e' un flusso: un messaggio puo' arrivare a pezzi, oppure piu'
    // messaggi possono arrivare insieme. Per questo teniamo un buffer:
    // si estrae il primo messaggio e il resto rimane per la lettura dopo.
    // Restituisce null se il client si e' disconnesso.
    string RiceviMessaggio()
    {
        while (buffer.IndexOf("$") == -1)
        {
            int bytesRec = clientSocket.Receive(bytes);
            if (bytesRec == 0) return null;      // connessione chiusa
            buffer += Encoding.ASCII.GetString(bytes, 0, bytesRec);
        }
        int pos = buffer.IndexOf("$");
        string messaggio = buffer.Substring(0, pos);
        buffer = buffer.Substring(pos + 1);
        return messaggio;
    }

    // Invia un messaggio al client aggiungendo il terminatore '$'
    public void Invia(string messaggio)
    {
        if (messaggio == null) return;   // niente da inviare (risposta gia' spedita)
        lock (lockInvio)
        {
            try
            {
                byte[] msg = Encoding.ASCII.GetBytes(messaggio + "$");
                clientSocket.Send(msg);
            }
            catch (Exception)
            {
                Connesso = false;   // il client se n'e' andato
            }
        }
    }

    public void doClient()
    {
        try
        {
            string data;
            while ((data = RiceviMessaggio()) != null)
            {
                string[] campi = data.Split('|');
                string comando = campi[0];

                if (comando == "QUIT")
                    break;
                else if (comando == "NOME" && campi.Length > 1)
                {
                    string nome = SynchronousSocketListener.Pulisci(campi[1]);
                    Nome = nome != "" ? nome : "Studente";
                    Console.WriteLine("\n[+] Connesso: {0} ({1})", Nome, Indirizzo);
                    Invia("OK|Benvenuto " + Nome + "! " + SynchronousSocketListener.InfoOrari());
                }
                else if (comando == "LISTA")
                    Invia(SynchronousSocketListener.ListaProdotti());
                else if (comando == "ORDINA")
                {
                    string[] righe = new string[campi.Length - 1];
                    Array.Copy(campi, 1, righe, 0, righe.Length);
                    Invia(SynchronousSocketListener.ConfermaOrdine(this, righe));
                }
                else if (comando == "MIEI")
                    Invia(SynchronousSocketListener.OrdiniDelClient(this));
                else if (comando == "ANNULLA" && campi.Length > 1)
                {
                    int numero;
                    if (int.TryParse(campi[1], out numero))
                        Invia(SynchronousSocketListener.AnnullaOrdine(this, numero));
                    else
                        Invia("ERRORE|Numero ordine non valido.");
                }
                else
                    Invia("ERRORE|Comando sconosciuto.");
            }
        }
        catch (Exception)
        {
            // Errore di rete: il client si e' disconnesso in modo brusco
        }

        // Disconnessione: tolgo il client dalla lista e chiudo la socket
        Connesso = false;
        lock (SynchronousSocketListener.lockClient)
        {
            SynchronousSocketListener.clientConnessi.Remove(this);
        }
        Console.WriteLine("\n[-] Disconnesso: {0} ({1})", Nome, Indirizzo);
        try
        {
            clientSocket.Shutdown(SocketShutdown.Both);
            clientSocket.Close();
        }
        catch (Exception) { }
    }
}
